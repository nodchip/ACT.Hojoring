libopus.dll
libsodium.dll
は、"必ず" ACT本体と "同じディレクトリ" に配置してください。

Advanced Combat Tracker.exe
libopus.dll
libsodium.dll
という位置関係が正しいです。
