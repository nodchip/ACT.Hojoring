ACT.UltraScouter
(C)anoyetta, 2017

1. Installation
step. 1
  resources
  ACT.UltraScouter.NLog.config
  FFXIV.Framework.Dialog.exe
  ACT.UltraScouter.Core.dll
  ACT.UltraScouter.dll
  FFXIV.Framework.Dialog.Wrapper.dll
  FFXIV.Framework.dll
  FirstFloor.ModernUI.dll
  Microsoft.Practices.ServiceLocation.dll
  NAudio.dll
  NLog.dll
  Prism.dll
  Prism.Wpf.dll
  System.Windows.Interactivity.dll

  Copy the above to the folder where ACT.exe is installed.

step. 2
  1) Show [Advanced Combat Tracker] -> [Plugins] -> [Plugin List]
  2) Click [Browse...]
  3) Select a "ACT.UltraScouter.dll" -> [Open]
  4) Click [Add/Enable Plugin]

2. FAQ
Q1. How do change the Action Name to English?
  1) Rename "resources\xivdb\Action.csv" to "resources\xivdb\Action_jp.csv".
  2) Rename "resources\xivdb\Action_en.csv" to "resources\xivdb\Action.csv".
  3) Reboot ACT.exe.
